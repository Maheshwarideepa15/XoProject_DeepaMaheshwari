﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Moq;
using NUnit.Framework;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using XOProject.Controller;
namespace XOProject.Tests
{
    public class PortfolioControllerTest
    {
        private readonly Mock<IPortfolioRepository> _portfolioRepositoryMock = new Mock<IPortfolioRepository>();
        private readonly PortfolioController _portfolioController;

        private IEnumerable<Portfolio> portfolio;
        private List<Trade> trade = new List<Trade>()
            {
                new Trade{
                    Id=1,
                    NoOfShares=2,
                    Action="BUY",
                    PortfolioId=1,
                    Price= 89.0m,
                    Symbol="REL"
               }
            };


        public PortfolioControllerTest()
        {
            portfolio = getPortfolioMockData();
            var mock = portfolio.AsQueryable().BuildMock();
            _portfolioRepositoryMock.Setup(x => x.GetAll()).Returns(mock.Object);
            _portfolioController = new PortfolioController(_portfolioRepositoryMock.Object);

        }

        private IEnumerable<Portfolio> getPortfolioMockData()
        {
            return new List<Portfolio>
            {
               new Portfolio{
                    Id=1,
                    Name="Brat",
                    Trade = trade
                    },
               new Portfolio{
                    Id=2,
                    Name="John"
               }
            }.AsQueryable();
        }

        [Test]
        public async Task GetPortfolioInfo_CalledOnlyOnce()
        {
            int portfolioId = 1;

            //Act
            var result = await _portfolioController.GetPortfolioInfo(portfolioId);
            _portfolioRepositoryMock.Verify(mock => mock.GetAll(), Times.Once());
        }


        [Test]
        public async Task GetPortfolioInfo_ReturnsNotFound()
        {
            int portfolioId = 9999;

            //Act
            var result = await _portfolioController.GetPortfolioInfo(portfolioId);

            Assert.NotNull(result);

            var notFoundResult = result as BadRequestResult;
            Assert.NotNull(notFoundResult);
            Assert.AreEqual(StatusCodes.Status400BadRequest, notFoundResult.StatusCode);

        }

        [Test]
        public async Task GetPortfolioInfo_ReturnsOKResult()
        {
            int portfolioId = 1;

            // Act
            var result = await _portfolioController.GetPortfolioInfo(portfolioId);

            Assert.NotNull(result);

            var okResult = result as OkObjectResult;
            Assert.NotNull(okResult);
            Assert.AreEqual(StatusCodes.Status200OK, okResult.StatusCode);

        }
        [Test]
        public async Task Post_ShouldInsertNewPortfolio()
        {
            // Arrange
            var portfolio = new Portfolio
            {
               Id = 3,
               Name = "Monica S"
            };

            // Act
            var result = await _portfolioController.Post(portfolio);

            // Assert
            Assert.NotNull(result);
            var createdResult = result as CreatedResult;
            Assert.NotNull(createdResult);
            Assert.AreEqual(StatusCodes.Status201Created, createdResult.StatusCode);
        }

        [Test]
        public async Task Post_ShouldNotInsertNewPortfolio()
        {
            // Arrange
            var portfolio = new Portfolio
            {
                Id = 3,
                Name = null
            };
            _portfolioController.ModelState.AddModelError("Name", "Name is Required");

            // Act
            var result = await _portfolioController.Post(portfolio);

            // Assert
            Assert.NotNull(result);
            var createdResult = result as BadRequestObjectResult;
            Assert.NotNull(createdResult);
            Assert.AreEqual(StatusCodes.Status400BadRequest, createdResult.StatusCode);
        }
    }
}
