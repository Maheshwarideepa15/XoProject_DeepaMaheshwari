using System;
using System.Threading.Tasks;
using XOProject.Controller;
using Microsoft.AspNetCore.Mvc;
using NUnit.Framework;
using Moq;
using System.Collections.Generic;
using System.Linq;
using Microsoft.AspNetCore.Http;

namespace XOProject.Tests
{
    public class ShareControllerTests
    {
        private readonly Mock<IShareRepository> _shareRepositoryMock = new Mock<IShareRepository>();

        private readonly ShareController _shareController;

        private IEnumerable<HourlyShareRate> hourlySharedRate;
        public ShareControllerTests()
        {
            hourlySharedRate = getHourlyShareRateMockData();
            var mock = hourlySharedRate.AsQueryable().BuildMock();
            _shareRepositoryMock.Setup(x => x.Query()).Returns(mock.Object);
            _shareController = new ShareController(_shareRepositoryMock.Object);
            
        }

        private IEnumerable<HourlyShareRate> getHourlyShareRateMockData()
        {
            return new List<HourlyShareRate>
            {
               new HourlyShareRate{
                    Id=1,
                    TimeStamp = new DateTime(2018, 12, 1, 1, 0, 0, 0, DateTimeKind.Unspecified),
                    Symbol="REL",
                    Rate = 80m
                },
                 new HourlyShareRate{
                    Id=2,
                    TimeStamp = new DateTime(2018, 12, 1, 2, 0, 0, 0, DateTimeKind.Unspecified),
                    Symbol="REL",
                    Rate = 97m
                },
                    new HourlyShareRate{
                    Id=3,
                    TimeStamp = new DateTime(2018, 12, 1, 3, 0, 0, 0, DateTimeKind.Unspecified),
                    Symbol="REL",
                    Rate = 109m
                },
                    new HourlyShareRate{
                    Id=4,
                    TimeStamp = new DateTime(2018, 12, 1, 1, 0, 0, 0, DateTimeKind.Unspecified),
                    Symbol="CBI",
                    Rate = 109m
                }

            }.AsQueryable();

        }

        [Test]
        public async Task UpdateLastPrice_IsUpdatedLastPrice()
        {
            // Arrange
            String symbol = "CBI";
            decimal price = hourlySharedRate.Where(x=>x.Symbol.Equals(symbol)).Select(y => y.Rate).OrderByDescending(o=>o).FirstOrDefault();
            price += 10;
            // Act
            await _shareController.UpdateLastPrice(symbol);
            decimal updatedPrice = hourlySharedRate.Where(x => x.Symbol.Equals(symbol)).Select(y => y.Rate).OrderByDescending(o => o).FirstOrDefault();
            Assert.AreEqual(price, updatedPrice);

        }


        [Test]
        public async Task Post_ShouldInsertHourlySharePrice()
        {
            var hourRate = new HourlyShareRate
            {
                Symbol = "CBI",
                Rate = 330.0M,
                TimeStamp = new DateTime(2018, 08, 17, 5, 0, 0)
            };

            // Arrange

            // Act
            var result = await _shareController.Post(hourRate);

            // Assert
            Assert.NotNull(result);
            var createdResult = result as CreatedResult;
            Assert.NotNull(createdResult);
            Assert.AreEqual(StatusCodes.Status201Created, createdResult.StatusCode);
        }

        [Test]
        public async Task Post_ShouldNotInsertHourlySharePrice()
        {
            var hourRate = new HourlyShareRate
            {
                Symbol = null,
                Rate = 330.0M,
                TimeStamp = new DateTime(2018, 08, 17, 5, 0, 0)
            };

            _shareController.ModelState.AddModelError("Symbol", "Symbol is required");
            // Arrange

            // Act
            var result = await _shareController.Post(hourRate);

            // Assert
            Assert.NotNull(result);
            var createdResult = result as BadRequestObjectResult;
            Assert.NotNull(createdResult);
            Assert.AreEqual(StatusCodes.Status400BadRequest, createdResult.StatusCode);
        }

        [Test]
        public async Task Gets_ReturnsNotFound()
        {
            string symbol = "TRP";

            //Act
            var result = await _shareController.Get(symbol);

            Assert.NotNull(result);

            var notFoundResult = result as BadRequestResult;
            Assert.NotNull(notFoundResult);
            Assert.AreEqual(StatusCodes.Status400BadRequest, notFoundResult.StatusCode);

        }


        [Test]
        public async Task Gets_ReturnsOKResult()
        {
            string symbol = "REL";

            //Act
            var result = await _shareController.Get(symbol);

            //Assert
            Assert.NotNull(result);

            var okResult = result as OkObjectResult;
            Assert.NotNull(okResult);
            Assert.AreEqual(StatusCodes.Status200OK, okResult.StatusCode);

        }

        [Test]
        public async Task GetLatestPrice_ResultNotFound()
        {
            string symbol = "TRP";

            //Act
            var result = await _shareController.GetLatestPrice(symbol);

            //Assert
            Assert.NotNull(result);
            var okResult = result as BadRequestResult;
            Assert.NotNull(okResult);
            Assert.AreEqual(StatusCodes.Status400BadRequest, okResult.StatusCode);

        }

        [Test]
        public async Task GetLatestPrice_ReturnsOKResult()
        {
            string symbol = "REL";

            //Act
            var result = await _shareController.GetLatestPrice(symbol);

            //Assert
            Assert.NotNull(result);
            var okResult = result as OkObjectResult;
            Assert.NotNull(okResult);
            Assert.AreEqual(StatusCodes.Status200OK, okResult.StatusCode);

        }

    }
}
