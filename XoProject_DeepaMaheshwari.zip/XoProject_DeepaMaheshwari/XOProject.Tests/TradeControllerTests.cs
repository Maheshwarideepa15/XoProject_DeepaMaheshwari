﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Moq;
using NUnit.Framework;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using XOProject.Controller;

namespace XOProject.Tests
{
    public class TradeControllerTests
    {
        private readonly Mock<ITradeRepository> _tradeRepositoryMock = new Mock<ITradeRepository>();
        private readonly TradeController _tradeController;

        private IEnumerable<Trade> trade;

        public TradeControllerTests()
        {
            trade = getTradeMockData();
            var mock = trade.AsQueryable().BuildMock();
            _tradeRepositoryMock.Setup(x => x.Query()).Returns(mock.Object);
            _tradeController = new TradeController(_tradeRepositoryMock.Object);

        }

        private IEnumerable<Trade> getTradeMockData()
        {
            return new List<Trade>
            {
               new Trade{
                    Id=1,
                    NoOfShares=2,
                    Action="BUY",
                    PortfolioId=1,
                    Price= default(decimal),
                    Symbol="REL"
                },
                 new Trade{
                    Id=2,
                    NoOfShares=2,
                    Action="SELL",
                    PortfolioId=2,
                    Price= default(decimal),
                    Symbol="REL"
                },
                    new Trade{
                    Id=3,
                    NoOfShares=2,
                    Action="BUY",
                    PortfolioId=3,
                    Price= default(decimal),
                    Symbol="CBI"
                }
            }.AsQueryable();

        }
        [Test]
        public async Task GetAllTradings_CalledOnlyOnce()
        {
            int portfolioId = 1;

            //Act
            var result = await _tradeController.GetAllTradings(portfolioId);
            _tradeRepositoryMock.Verify(mock => mock.Query(), Times.Once());

        }

        [Test]
        public async Task GetAllTradings_ReturnsNotFound()
        {
            int portfolioId = 9999;

            //Act
            var result = await _tradeController.GetAllTradings(portfolioId);

            Assert.NotNull(result);

            var notFoundResult = result as NotFoundResult;
            Assert.NotNull(notFoundResult);
            Assert.AreEqual(StatusCodes.Status404NotFound, notFoundResult.StatusCode);

        }

        [Test]
        public async Task GetAllTradings_ReturnsOKResult()
        {
            int portfolioId = 1;

            //Act
            var result = await _tradeController.GetAllTradings(portfolioId);

            Assert.NotNull(result);

            var okResult = result as OkObjectResult;
            Assert.NotNull(okResult);
            Assert.AreEqual(StatusCodes.Status200OK, okResult.StatusCode);

        }

        [Test]
        public async Task GetAnalysis_ReturnsNotFound()
        {
            string symbol = "PTI";

            //Act
            var result = await _tradeController.GetAnalysis(symbol);

            Assert.NotNull(result);

            var notFoundResult = result as NotFoundResult;
            Assert.NotNull(notFoundResult);
            Assert.AreEqual(StatusCodes.Status404NotFound, notFoundResult.StatusCode);

        }

        [Test]
        public async Task GetAnalysis_ReturnsOKResult()
        {
            string symbol = "CBI";

            //Act
            var result = await _tradeController.GetAnalysis(symbol);

            Assert.NotNull(result);

            var okResult = result as OkObjectResult;
            Assert.NotNull(okResult);
            Assert.AreEqual(200, okResult.StatusCode);

        }

        
    }
}
