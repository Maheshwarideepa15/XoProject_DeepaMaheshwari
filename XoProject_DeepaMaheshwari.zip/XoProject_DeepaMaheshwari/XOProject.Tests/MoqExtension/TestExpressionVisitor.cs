﻿using System.Linq.Expressions;

namespace XOProject.Tests
{
    public class TestExpressionVisitor : ExpressionVisitor
    {
    }
}