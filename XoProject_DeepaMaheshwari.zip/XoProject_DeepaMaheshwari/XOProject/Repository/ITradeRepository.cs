﻿namespace XOProject
{
    public interface ITradeRepository : IGenericRepository<Trade>
    {
    }
}