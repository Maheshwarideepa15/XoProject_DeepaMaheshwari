﻿namespace XOProject
{
    public interface IShareRepository : IGenericRepository<HourlyShareRate>
    {
    }
}