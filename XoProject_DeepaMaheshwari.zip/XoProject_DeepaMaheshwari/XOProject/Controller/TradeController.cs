﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;


namespace XOProject.Controller
{
    [Route("api/Trade/")]
    public class TradeController : ControllerBase
    {
        private ITradeRepository _tradeRepository { get; set; }
        
        public TradeController(ITradeRepository tradeRepository)
        {
            _tradeRepository = tradeRepository;
        }


        [HttpGet("{portFolioid}")]
        public async Task<IActionResult> GetAllTradings([FromRoute]int portFolioid)
        {
            var trades =  await _tradeRepository.Query().Where(x => x.PortfolioId.Equals(portFolioid)).ToListAsync();
            if (trades!=null && trades.Any()) {
                return Ok(trades);
            }

            return NotFound();
        }


        /// <summary>
        /// For a given symbol of share, get the statistics for that particular share calculating the maximum, minimum, average and sum of price for all the trades that happened for that share. 
        /// Group statistics individually for all BUY trades and SELL trades separately.
        /// </summary>
        /// <param name="symbol"></param>
        /// <returns></returns>

        [HttpGet("Analysis/{symbol}")]
        public async Task<IActionResult> GetAnalysis([FromRoute]string symbol)
        {
            var list = new List<TradeAnalysis>();
            list =  await _tradeRepository.Query().Where(x => x.Symbol.Equals(symbol)).GroupBy(y => y.Action)
                        .Select(T => new TradeAnalysis
                        {
                            Sum = T.Sum(y => y.Price),
                            Average = T.Average(y => y.Price),
                            Maximum = T.Max(y => y.Price),
                            Minimum = T.Min(y => y.Price),
                            Action = T.Key
                        }).ToListAsync();

            if (list!=null && list.Any())
            {
                return Ok(list);
            }
            return NotFound();
        }


    }
}
