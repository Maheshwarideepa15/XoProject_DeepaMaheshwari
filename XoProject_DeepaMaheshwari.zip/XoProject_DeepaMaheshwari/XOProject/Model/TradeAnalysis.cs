﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace XOProject
{
    public class TradeAnalysis
    {
        public decimal Sum { get; set; }

        public decimal Average { get; set; }

        public decimal Maximum { get; set; }

        public decimal Minimum { get; set; }

        public string Action { get; set; }
    }
}
